Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by menegass ( http://www.freesound.org/people/menegass/  )
You can find this pack online at: http://www.freesound.org/people/menegass/packs/6393/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 100067__menegass__Gui_DRUM_TOM_MID_soft.wav
    * url: http://www.freesound.org/people/menegass/sounds/100067/
    * license: Creative Commons 0
  * 100066__menegass__Gui_DRUM_TOM_MID_hard.wav
    * url: http://www.freesound.org/people/menegass/sounds/100066/
    * license: Creative Commons 0
  * 100065__menegass__Gui_DRUM_TOM_LO_soft.wav
    * url: http://www.freesound.org/people/menegass/sounds/100065/
    * license: Creative Commons 0
  * 100064__menegass__Gui_DRUM_TOM_LO_hard.wav
    * url: http://www.freesound.org/people/menegass/sounds/100064/
    * license: Creative Commons 0
  * 100063__menegass__Gui_DRUM_TOM_HI_soft.wav
    * url: http://www.freesound.org/people/menegass/sounds/100063/
    * license: Creative Commons 0
  * 100062__menegass__Gui_DRUM_TOM_HI_hard.wav
    * url: http://www.freesound.org/people/menegass/sounds/100062/
    * license: Creative Commons 0
  * 100061__menegass__Gui_DRUM_SPLASH_soft.wav
    * url: http://www.freesound.org/people/menegass/sounds/100061/
    * license: Creative Commons 0
  * 100060__menegass__Gui_DRUM_SPLASH_hard.wav
    * url: http://www.freesound.org/people/menegass/sounds/100060/
    * license: Creative Commons 0
  * 100059__menegass__Gui_DRUM_SNARE_soft.wav
    * url: http://www.freesound.org/people/menegass/sounds/100059/
    * license: Creative Commons 0
  * 100058__menegass__Gui_DRUM_SNARE_hard.wav
    * url: http://www.freesound.org/people/menegass/sounds/100058/
    * license: Creative Commons 0
  * 100057__menegass__Gui_DRUM_CYN_soft.wav
    * url: http://www.freesound.org/people/menegass/sounds/100057/
    * license: Creative Commons 0
  * 100056__menegass__Gui_DRUM_CYN_hard.wav
    * url: http://www.freesound.org/people/menegass/sounds/100056/
    * license: Creative Commons 0
  * 100055__menegass__Gui_DRUM_CO.wav
    * url: http://www.freesound.org/people/menegass/sounds/100055/
    * license: Creative Commons 0
  * 100054__menegass__Gui_DRUM_CH.wav
    * url: http://www.freesound.org/people/menegass/sounds/100054/
    * license: Creative Commons 0
  * 100053__menegass__Gui_DRUM_CC.wav
    * url: http://www.freesound.org/people/menegass/sounds/100053/
    * license: Creative Commons 0
  * 100052__menegass__Gui_DRUM_BD_soft.wav
    * url: http://www.freesound.org/people/menegass/sounds/100052/
    * license: Creative Commons 0
  * 100051__menegass__Gui_DRUM_BD_hard.wav
    * url: http://www.freesound.org/people/menegass/sounds/100051/
    * license: Creative Commons 0

